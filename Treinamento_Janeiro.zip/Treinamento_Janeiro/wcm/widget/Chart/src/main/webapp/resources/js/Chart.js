var MyWidget = SuperWidget.extend({
    //variáveis da widget
    variavelNumerica: null,
    variavelCaracter: null,

    //método iniciado quando a widget é carregada
    init: function() {
    	
    	var ds = DatasetFactory.getDataset ("ds_chart", null, null, null);
    	var dados = [];
    	var produto = [];
    	
    		for (x=0; x<ds.values.length; x++){
    			dados [x] = ds.values [x].Valor;
    			produto [x] =ds.values [x].Produto;
   		}
    	
       	
        	var data = {
    		    labels: produto,
    		    datasets: [
    		        {
    		            label: "My First dataset",
    		            fillColor: "rgba(220,220,220,0.2)",
    		            strokeColor: "rgba(220,220,220,1)",
    		            pointColor: "rgba(220,220,220,1)",
    		            pointStrokeColor: "#fff",
    		            pointHighlightFill: "#fff",
    		            pointHighlightStroke: "rgba(220,220,220,1)",
    		            data: dados
    		        }
    		    ]
    		};
        	
             	
        	var chart = FLUIGC.chart('#MY_SELECTOR', {
        	    id: 'set_an_id_for_my_chart',
        	    width: '700',
        	    height: '200',
        	    /* See the list of options */
        	});
        	// call the line function
        	var lineChart = chart.line(data, "");
    	
    },
  
    //BIND de eventos
    bindings: {
        local: {
            'execute': ['click_executeAction']
        },
        global: {}
    },
 
    executeAction: function(htmlElement, event) {
    }

});

