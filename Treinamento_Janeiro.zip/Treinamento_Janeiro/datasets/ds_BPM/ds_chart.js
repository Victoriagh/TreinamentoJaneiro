function defineStructure() {

}
function onSync(lastSyncDate) {

}
function createDataset(fields, constraints, sortFields) {
	
	var dataset = DatasetBuilder.newDataset ();
	
	dataset.addColumn ("Produto");
	dataset.addColumn ("Valor");
	
	dataset.addRow(new Array ("Software", 899));
	dataset.addRow(new Array ("Hardaware", 99));
	dataset.addRow(new Array ("Mouse", 30));
	dataset.addRow(new Array ("Teclado", 80));
	dataset.addRow(new Array ("Monitor", 500));
	dataset.addRow(new Array ("Fone de Ouvido", 100));
	
	return dataset; 
	
	
	
	
	

}function onMobileSync(user) {

}