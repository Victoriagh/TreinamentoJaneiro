function defineStructure() {

}
function onSync(lastSyncDate) {

}
function createDataset(fields, constraints, sortFields) {
	
	var dataset = DatasetBuilder.newDataset ();
	
	//Cria Colunas
	dataset.addColumn("Sigla");
	dataset.addColumn("Estado");
	dataset.addColumn("Capital");
	dataset.addColumn("Area");
	
	//Cria Registros
	dataset.addRow(new Array("AM","Amazonas","Manaus",909099));
	dataset.addRow(new Array("PA","Para","Belem",79824987));
	dataset.addRow(new Array("MT","Mato Grosso","Cuiába",998989));
	dataset.addRow(new Array("TO","Tocantins","Palmas",737447));
	dataset.addRow(new Array("PI","Piauí","Teresina",5363563));
		
	return dataset; 
	

}function onMobileSync(user) {

}